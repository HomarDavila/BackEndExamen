<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>Soluci&oacute;n al Examen PHP Developer</title>
    </head>
    <body>
        <h3>Soluci&oacute;n al Examen PHP Developer</h3>
        <h4>parte 1</h4>
        <a href="parte1/problema01.php">Problema 01</a>
        <br>
        <a href="parte1/problema02.php">Problema 02</a>
        <br>
        <a href="parte1/problema03.php">Problema 03</a>
        <h4>parte 2</h4>
        <a href="parte2/public/index.php">Problema 04</a>
    </body>
</html>
